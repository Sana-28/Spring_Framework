package com.bridgeit.dao;

import com.bridgeit.model.User;

public class UserDao {
	
	public void saveUser(User user){
		
	}

}
